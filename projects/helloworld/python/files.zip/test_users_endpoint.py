"""Integration tests for /users endpoints."""

from fastapi import status


def _create_user(client, email="alice@example.com", full_name="Alice"):
    return client.post("/api/v1/users", json={"email": email, "full_name": full_name})


class TestCreateUser:
    def test_creates_user(self, client):
        response = _create_user(client)
        assert response.status_code == status.HTTP_201_CREATED
        body = response.json()
        assert body["email"] == "alice@example.com"
        assert body["full_name"] == "Alice"
        assert body["is_active"] is True
        assert "id" in body

    def test_duplicate_email_returns_409(self, client):
        _create_user(client)
        response = _create_user(client)
        assert response.status_code == status.HTTP_409_CONFLICT
        assert response.json()["error"]["type"] == "conflict"

    def test_invalid_email_returns_422(self, client):
        response = client.post("/api/v1/users", json={"email": "nope", "full_name": "X"})
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY


class TestGetUser:
    def test_returns_user(self, client):
        created = _create_user(client).json()
        response = client.get(f"/api/v1/users/{created['id']}")
        assert response.status_code == status.HTTP_200_OK
        assert response.json()["id"] == created["id"]

    def test_missing_user_returns_404(self, client):
        response = client.get("/api/v1/users/9999")
        assert response.status_code == status.HTTP_404_NOT_FOUND
        assert response.json()["error"]["type"] == "not_found"


class TestListUsers:
    def test_empty(self, client):
        assert client.get("/api/v1/users").json() == []

    def test_returns_all(self, client):
        _create_user(client, email="a@example.com")
        _create_user(client, email="b@example.com")
        body = client.get("/api/v1/users").json()
        assert len(body) == 2

    def test_respects_limit(self, client):
        for i in range(3):
            _create_user(client, email=f"u{i}@example.com")
        body = client.get("/api/v1/users", params={"limit": 2}).json()
        assert len(body) == 2


class TestUpdateUser:
    def test_partial_update(self, client):
        created = _create_user(client).json()
        response = client.patch(f"/api/v1/users/{created['id']}", json={"full_name": "Alice2"})
        assert response.status_code == status.HTTP_200_OK
        assert response.json()["full_name"] == "Alice2"

    def test_deactivate(self, client):
        created = _create_user(client).json()
        response = client.patch(f"/api/v1/users/{created['id']}", json={"is_active": False})
        assert response.json()["is_active"] is False

    def test_email_collision_returns_409(self, client):
        a = _create_user(client, email="a@example.com").json()
        _create_user(client, email="b@example.com")
        response = client.patch(f"/api/v1/users/{a['id']}", json={"email": "b@example.com"})
        assert response.status_code == status.HTTP_409_CONFLICT


class TestDeleteUser:
    def test_deletes(self, client):
        created = _create_user(client).json()
        response = client.delete(f"/api/v1/users/{created['id']}")
        assert response.status_code == status.HTTP_204_NO_CONTENT
        assert client.get(f"/api/v1/users/{created['id']}").status_code == status.HTTP_404_NOT_FOUND

    def test_missing_returns_404(self, client):
        assert client.delete("/api/v1/users/9999").status_code == status.HTTP_404_NOT_FOUND


class TestUserGreetings:
    def test_create_greeting_with_user(self, client):
        user = _create_user(client).json()
        response = client.post(
            "/api/v1/greetings",
            json={"name": "Hi", "user_id": user["id"]},
        )
        assert response.status_code == status.HTTP_201_CREATED
        assert response.json()["user_id"] == user["id"]

    def test_create_greeting_with_unknown_user_returns_404(self, client):
        response = client.post("/api/v1/greetings", json={"name": "Hi", "user_id": 9999})
        assert response.status_code == status.HTTP_404_NOT_FOUND

    def test_list_user_greetings(self, client):
        user = _create_user(client).json()
        client.post(
            "/api/v1/greetings",
            json={"name": "First", "user_id": user["id"]},
        )
        client.post(
            "/api/v1/greetings",
            json={"name": "Second", "user_id": user["id"]},
        )
        # Plus an unrelated greeting (no user)
        client.post("/api/v1/greetings", json={"name": "Other"})

        response = client.get(f"/api/v1/users/{user['id']}/greetings")
        assert response.status_code == status.HTTP_200_OK
        body = response.json()
        assert len(body) == 2
        assert all(g["user_id"] == user["id"] for g in body)

    def test_list_greetings_for_unknown_user_returns_404(self, client):
        assert client.get("/api/v1/users/9999/greetings").status_code == status.HTTP_404_NOT_FOUND

    def test_response_includes_request_id_header(self, client):
        response = client.get("/api/v1/users")
        assert "x-request-id" in {k.lower() for k in response.headers}
