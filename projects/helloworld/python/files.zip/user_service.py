"""User service: business logic for user management.

Uses UserRepository for persistence and raises domain exceptions
(NotFoundError, ConflictError) instead of HTTP errors. The API layer
translates those into 404/409 responses via exception handlers.
"""

import logging

from sqlalchemy.orm import Session

from app.exceptions import ConflictError, NotFoundError
from app.models.user import User
from app.repositories.user_repository import UserRepository
from app.schemas.user import UserCreate, UserUpdate

logger = logging.getLogger(__name__)


class UserService:
    """User-related business logic."""

    def __init__(self, db: Session) -> None:
        self.db = db
        self.repo = UserRepository(db)

    def create(self, payload: UserCreate) -> User:
        if self.repo.get_by_email(payload.email) is not None:
            raise ConflictError(f"User with email {payload.email!r} already exists")

        user = User(email=payload.email, full_name=payload.full_name)
        user = self.repo.add(user)
        self.db.commit()
        self.db.refresh(user)
        logger.info("created user id=%d email=%s", user.id, user.email)
        return user

    def get(self, user_id: int) -> User:
        user = self.repo.get(user_id)
        if user is None:
            raise NotFoundError(f"User {user_id} not found")
        return user

    def list_all(self, *, limit: int = 100, offset: int = 0) -> list[User]:
        return self.repo.list_all(limit=limit, offset=offset)

    def update(self, user_id: int, payload: UserUpdate) -> User:
        user = self.get(user_id)
        # Only fields the client actually set
        updates = payload.model_dump(exclude_unset=True)

        # Guard against email collisions
        if (
            "email" in updates
            and updates["email"] != user.email
            and self.repo.get_by_email(updates["email"]) is not None
        ):
            raise ConflictError(f"User with email {updates['email']!r} already exists")

        for field, value in updates.items():
            setattr(user, field, value)

        self.db.commit()
        self.db.refresh(user)
        logger.info("updated user id=%d fields=%s", user.id, list(updates))
        return user

    def delete(self, user_id: int) -> None:
        user = self.get(user_id)
        self.repo.delete(user)
        self.db.commit()
        logger.info("deleted user id=%d", user_id)
