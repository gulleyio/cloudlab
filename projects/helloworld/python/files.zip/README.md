# FastAPI Hello World — Production-Shaped Example

A small but complete FastAPI project demonstrating the patterns and structure you'd use in a real production codebase: layered architecture, repository pattern, Alembic migrations, structured logging with request IDs, custom exceptions with global handlers, Docker, CI, linting, type-checking, and unit + integration tests.

The app exposes two business modules — **users** and **greetings** — with a one-to-many relationship between them.

## Project layout

```
app/
├── api/                    # HTTP routes (thin — only translate HTTP <-> domain)
│   ├── dependencies.py     # Reusable Annotated[..., Depends()] aliases
│   ├── greetings.py
│   ├── health.py
│   ├── hello.py
│   └── users.py
├── core/
│   ├── config.py           # pydantic-settings, single source of truth
│   └── logging.py          # JSON logging + request_id ContextVar
├── db/
│   └── session.py          # Engine, sessionmaker, get_db dependency
├── exceptions/             # Domain exceptions (NotFoundError, ConflictError, ...)
├── middleware/
│   ├── exception_handlers.py   # Translate domain exceptions -> HTTP responses
│   └── request_id.py           # Per-request UUID + access logs
├── models/                 # SQLAlchemy 2.0 ORM models
├── repositories/           # Data access layer (one per aggregate root)
│   ├── base.py             # Generic CRUD building blocks
│   ├── greeting_repository.py
│   └── user_repository.py
├── schemas/                # Pydantic request/response models (Create/Update/Read split)
├── services/               # Business logic — no HTTP, no FastAPI imports
└── main.py                 # App factory, middleware wiring, lifespan

alembic/                    # DB migrations
tests/
├── unit/                   # Pure logic + service tests against in-memory DB
└── integration/            # Full-stack tests via TestClient
```

### Why these layers?

The strict separation between `api/`, `services/`, `repositories/`, and `models/` is the most important pattern in this project. Each layer has one job:

- **`api/`** — HTTP only. Parses requests, calls a service, serializes the response. No business rules, no SQL.
- **`services/`** — Business logic. Orchestrates repositories, enforces invariants, raises domain exceptions. No FastAPI imports, no HTTP status codes.
- **`repositories/`** — Data access. All SQLAlchemy queries live here. Services never write `.query()` or `select()` directly.
- **`models/`** — ORM definitions only. No methods that do queries (those go in repos).

This makes services trivially testable without HTTP, and lets you swap the storage layer or add a CLI/job runner without touching business logic.

## Endpoints

| Method | Path                                | Description                                |
|--------|-------------------------------------|--------------------------------------------|
| GET    | `/api/v1/health`                    | Service + DB health check                  |
| GET    | `/api/v1/hello?name=...`            | Stateless greeting                         |
| POST   | `/api/v1/greetings`                 | Create a greeting (optionally tied to a user) |
| GET    | `/api/v1/greetings`                 | List recent greetings                      |
| POST   | `/api/v1/users`                     | Create a user                              |
| GET    | `/api/v1/users`                     | List users                                 |
| GET    | `/api/v1/users/{id}`                | Get a user                                 |
| PATCH  | `/api/v1/users/{id}`                | Partial update                             |
| DELETE | `/api/v1/users/{id}`                | Delete a user (cascades to greetings)      |
| GET    | `/api/v1/users/{id}/greetings`      | List a user's greetings                    |

Open `/docs` for the Swagger UI once running.

## Quick start

```bash
cp .env.example .env
python -m venv .venv && source .venv/bin/activate
make dev                  # install deps + pre-commit hooks
make db-up                # start Postgres in Docker
make migrate              # apply migrations
make run                  # run the dev server with reload
```

Or run the whole stack containerised:

```bash
make docker-up            # builds the image, starts API + Postgres, runs migrations
```

## Tests

Tests use SQLite in-memory by default for speed; CI runs them against a real Postgres.

```bash
make test                 # all tests, SQLite
make test-cov             # with coverage
make test-pg              # against the dockerised Postgres
```

Each test runs inside a transaction that rolls back on teardown, so tests are isolated without recreating the schema between them. The `get_db` FastAPI dependency is overridden via `app.dependency_overrides` to inject the test session — that's the canonical FastAPI testing pattern.

## Migrations

Alembic is configured to read the database URL from `app.core.config` (single source of truth) and auto-detect changes from `Base.metadata`.

```bash
make migration MSG="add column foo"   # generate
make migrate                          # apply
```

In production the Docker entrypoint runs `alembic upgrade head` before the app starts.

## Patterns worth calling out

### `Annotated[..., Depends()]` for cleaner routes

`app/api/dependencies.py` defines reusable aliases like `UserServiceDep = Annotated[UserService, Depends(get_user_service)]` so route signatures stay readable:

```python
def create_user(payload: UserCreate, service: UserServiceDep) -> UserRead:
    ...
```

### Domain exceptions, not HTTPException

Services raise `NotFoundError`, `ConflictError`, etc. Global handlers in `app/middleware/exception_handlers.py` translate those into proper HTTP responses with a consistent error envelope:

```json
{ "error": { "type": "not_found", "message": "User 42 not found" } }
```

This means business logic stays HTTP-agnostic and produces uniform error responses across every endpoint.

### Separate Create / Update / Read schemas

`UserCreate` accepts what clients can send, `UserRead` shows what the API returns (server-set fields like `id`, `created_at`), and `UserUpdate` makes everything optional with `model_dump(exclude_unset=True)` for proper PATCH semantics.

### Request IDs for log correlation

Every request gets a UUID (or honours an incoming `X-Request-ID`). It's stored in a `ContextVar`, automatically attached to every log line via a logging filter, and echoed back in the response headers — so you can grep production logs for a single request without instrumenting any code.

### Application factory + lifespan

`create_app()` builds a fresh app on demand instead of relying on module-level side effects. The `lifespan` async context manager handles startup/shutdown in one place, and only auto-creates tables in `development` mode — production must use Alembic.

## Tooling

- **ruff** for lint + format (config in `pyproject.toml`)
- **mypy** in strict mode for type-checking
- **pre-commit** runs ruff + mypy on every commit (`make dev` installs the hook)
- **GitHub Actions** runs lint + type-check + tests against real Postgres on every push

## Things you'd add for a real production app

This is intentionally a starter; the next steps for a real service:

- **Authentication / authorization** — OAuth2 + JWT or session cookies; a `current_user` dependency
- **Rate limiting** — `slowapi` or an upstream gateway
- **Async DB** — swap to `async_sessionmaker` and `AsyncSession` if your workload is IO-bound enough to benefit
- **Settings per environment** — `.env.dev`, `.env.prod`, etc.
- **Observability** — OpenTelemetry tracing, Prometheus metrics, Sentry for error tracking
- **A staging seed script** — load deterministic fixtures via the service layer
