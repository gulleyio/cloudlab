"""Unit tests for UserService.

Uses the in-memory test DB session (provided by conftest) to exercise
service-layer logic without hitting the HTTP layer. Integration tests
cover the routes themselves separately.
"""

import pytest

from app.exceptions import ConflictError, NotFoundError
from app.schemas.user import UserCreate, UserUpdate
from app.services.user_service import UserService


@pytest.fixture
def service(db_session):
    return UserService(db_session)


class TestCreate:
    def test_creates_user(self, service):
        user = service.create(UserCreate(email="alice@example.com", full_name="Alice"))
        assert user.id is not None
        assert user.email == "alice@example.com"
        assert user.is_active is True

    def test_rejects_duplicate_email(self, service):
        service.create(UserCreate(email="a@example.com", full_name="A"))
        with pytest.raises(ConflictError, match="already exists"):
            service.create(UserCreate(email="a@example.com", full_name="A2"))


class TestGet:
    def test_raises_when_missing(self, service):
        with pytest.raises(NotFoundError):
            service.get(999)

    def test_returns_existing(self, service):
        created = service.create(UserCreate(email="b@example.com", full_name="B"))
        fetched = service.get(created.id)
        assert fetched.id == created.id


class TestUpdate:
    def test_partial_update(self, service):
        user = service.create(UserCreate(email="c@example.com", full_name="C"))
        updated = service.update(user.id, UserUpdate(full_name="C-new"))
        assert updated.full_name == "C-new"
        assert updated.email == "c@example.com"  # unchanged

    def test_rejects_email_collision(self, service):
        service.create(UserCreate(email="x@example.com", full_name="X"))
        other = service.create(UserCreate(email="y@example.com", full_name="Y"))
        with pytest.raises(ConflictError):
            service.update(other.id, UserUpdate(email="x@example.com"))

    def test_allows_setting_email_to_same_value(self, service):
        user = service.create(UserCreate(email="z@example.com", full_name="Z"))
        # No change in email — should not raise
        updated = service.update(user.id, UserUpdate(email="z@example.com"))
        assert updated.email == "z@example.com"


class TestDelete:
    def test_deletes_user(self, service):
        user = service.create(UserCreate(email="d@example.com", full_name="D"))
        service.delete(user.id)
        with pytest.raises(NotFoundError):
            service.get(user.id)

    def test_raises_when_missing(self, service):
        with pytest.raises(NotFoundError):
            service.delete(999)
