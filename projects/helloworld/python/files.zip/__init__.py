"""Domain-level exceptions.

Raised by the service/repository layers. The API layer translates
these into HTTP responses via exception handlers in app.middleware.
Keeping them HTTP-agnostic means services stay reusable from CLIs,
background jobs, etc.
"""


class AppError(Exception):
    """Base class for all application errors."""

    default_message: str = "An application error occurred"

    def __init__(self, message: str | None = None) -> None:
        super().__init__(message or self.default_message)
        self.message = message or self.default_message


class NotFoundError(AppError):
    """Requested resource does not exist."""

    default_message = "Resource not found"


class ConflictError(AppError):
    """Request conflicts with current state (e.g. duplicate)."""

    default_message = "Resource conflict"


class ValidationError(AppError):
    """Domain-level validation failure (distinct from Pydantic validation)."""

    default_message = "Validation failed"
