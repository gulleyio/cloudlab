"""Greeting service: business logic for greetings."""

import logging

from sqlalchemy.orm import Session

from app.exceptions import NotFoundError, ValidationError
from app.models.greeting import Greeting
from app.repositories.greeting_repository import GreetingRepository
from app.repositories.user_repository import UserRepository

logger = logging.getLogger(__name__)


def build_greeting_message(name: str) -> str:
    """Pure helper kept module-level for easy unit testing."""
    cleaned = name.strip()
    if not cleaned:
        raise ValidationError("name must not be empty")
    return f"Hello, {cleaned}!"


class GreetingService:
    def __init__(self, db: Session) -> None:
        self.db = db
        self.repo = GreetingRepository(db)
        self.users = UserRepository(db)

    def create(self, name: str, user_id: int | None = None) -> Greeting:
        if user_id is not None and self.users.get(user_id) is None:
            raise NotFoundError(f"User {user_id} not found")

        greeting = Greeting(
            name=name.strip(),
            message=build_greeting_message(name),
            user_id=user_id,
        )
        greeting = self.repo.add(greeting)
        self.db.commit()
        self.db.refresh(greeting)
        logger.info("created greeting id=%d", greeting.id)
        return greeting

    def list_recent(self, *, limit: int = 100) -> list[Greeting]:
        return self.repo.list_recent(limit=limit)

    def list_for_user(self, user_id: int, *, limit: int = 100) -> list[Greeting]:
        if self.users.get(user_id) is None:
            raise NotFoundError(f"User {user_id} not found")
        return self.repo.list_for_user(user_id, limit=limit)
