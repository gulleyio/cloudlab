"""Greetings endpoints — persist greetings in the database."""

from fastapi import APIRouter, Query, status

from app.api.dependencies import GreetingServiceDep
from app.schemas.greeting import GreetingCreate, GreetingRead

router = APIRouter(prefix="/greetings", tags=["greetings"])


@router.post(
    "",
    response_model=GreetingRead,
    status_code=status.HTTP_201_CREATED,
    summary="Create a greeting",
)
def create_greeting(payload: GreetingCreate, service: GreetingServiceDep) -> GreetingRead:
    greeting = service.create(name=payload.name, user_id=payload.user_id)
    return GreetingRead.model_validate(greeting)


@router.get("", response_model=list[GreetingRead], summary="List recent greetings")
def list_greetings(
    service: GreetingServiceDep, limit: int = Query(100, ge=1, le=500)
) -> list[GreetingRead]:
    return [GreetingRead.model_validate(g) for g in service.list_recent(limit=limit)]
