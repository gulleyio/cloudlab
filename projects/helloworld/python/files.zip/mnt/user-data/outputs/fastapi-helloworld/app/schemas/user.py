"""Pydantic schemas for users.

Best practice: separate schemas per use case rather than reusing the same
class for input and output. ``UserCreate`` accepts what the client can
send (email + name); ``UserRead`` shows what the API returns (server-set
fields like id and timestamps); ``UserUpdate`` makes everything optional
so PATCH semantics work cleanly.
"""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class UserBase(BaseModel):
    email: EmailStr = Field(..., description="Unique email address")
    full_name: str = Field(..., min_length=1, max_length=100)


class UserCreate(UserBase):
    """Payload for creating a user."""


class UserUpdate(BaseModel):
    """Payload for partial updates — all fields optional."""

    email: EmailStr | None = None
    full_name: str | None = Field(default=None, min_length=1, max_length=100)
    is_active: bool | None = None


class UserRead(UserBase):
    """User as returned by the API."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    is_active: bool
    created_at: datetime
