"""Pydantic schemas for greetings and shared responses."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class GreetingBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, description="Name to greet")


class GreetingCreate(GreetingBase):
    user_id: int | None = Field(default=None, description="Optional owning user ID")


class GreetingRead(GreetingBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    message: str
    created_at: datetime
    user_id: int | None = None


class HelloResponse(BaseModel):
    message: str = Field(..., examples=["Hello, World!"])


class HealthResponse(BaseModel):
    status: str = Field(..., examples=["ok"])
    database: str = Field(..., examples=["ok"])
