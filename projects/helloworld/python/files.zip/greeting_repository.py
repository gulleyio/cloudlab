"""Greeting repository."""

from sqlalchemy import select

from app.models.greeting import Greeting
from app.repositories.base import BaseRepository


class GreetingRepository(BaseRepository[Greeting]):
    model = Greeting

    def list_recent(self, *, limit: int = 100) -> list[Greeting]:
        """Newest first; id is the tiebreaker for identical timestamps."""
        stmt = (
            select(Greeting).order_by(Greeting.created_at.desc(), Greeting.id.desc()).limit(limit)
        )
        return list(self.db.scalars(stmt).all())

    def list_for_user(self, user_id: int, *, limit: int = 100) -> list[Greeting]:
        stmt = (
            select(Greeting)
            .where(Greeting.user_id == user_id)
            .order_by(Greeting.created_at.desc(), Greeting.id.desc())
            .limit(limit)
        )
        return list(self.db.scalars(stmt).all())
