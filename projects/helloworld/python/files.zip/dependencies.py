"""Reusable FastAPI dependencies.

Service factories live here so routes can ask for a fully-wired service
via Depends() rather than building them by hand. Keeps routes thin and
makes services trivial to override in tests.
"""

from typing import Annotated

from fastapi import Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.services.greeting_service import GreetingService
from app.services.user_service import UserService

DbSession = Annotated[Session, Depends(get_db)]


def get_user_service(db: DbSession) -> UserService:
    return UserService(db)


def get_greeting_service(db: DbSession) -> GreetingService:
    return GreetingService(db)


UserServiceDep = Annotated[UserService, Depends(get_user_service)]
GreetingServiceDep = Annotated[GreetingService, Depends(get_greeting_service)]
