"""User repository — all User-related DB queries live here."""

from sqlalchemy import select

from app.models.user import User
from app.repositories.base import BaseRepository


class UserRepository(BaseRepository[User]):
    model = User

    def get_by_email(self, email: str) -> User | None:
        stmt = select(User).where(User.email == email)
        return self.db.scalar(stmt)

    def list_active(self, *, limit: int = 100) -> list[User]:
        stmt = select(User).where(User.is_active.is_(True)).limit(limit)
        return list(self.db.scalars(stmt).all())
