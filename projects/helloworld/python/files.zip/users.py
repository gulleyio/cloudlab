"""User CRUD endpoints."""

from fastapi import APIRouter, Query, status

from app.api.dependencies import GreetingServiceDep, UserServiceDep
from app.schemas.greeting import GreetingRead
from app.schemas.user import UserCreate, UserRead, UserUpdate

router = APIRouter(prefix="/users", tags=["users"])


@router.post(
    "",
    response_model=UserRead,
    status_code=status.HTTP_201_CREATED,
    summary="Create a user",
)
def create_user(payload: UserCreate, service: UserServiceDep) -> UserRead:
    user = service.create(payload)
    return UserRead.model_validate(user)


@router.get("", response_model=list[UserRead], summary="List users")
def list_users(
    service: UserServiceDep,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
) -> list[UserRead]:
    users = service.list_all(limit=limit, offset=offset)
    return [UserRead.model_validate(u) for u in users]


@router.get("/{user_id}", response_model=UserRead, summary="Get a user by ID")
def get_user(user_id: int, service: UserServiceDep) -> UserRead:
    user = service.get(user_id)
    return UserRead.model_validate(user)


@router.patch("/{user_id}", response_model=UserRead, summary="Update a user")
def update_user(user_id: int, payload: UserUpdate, service: UserServiceDep) -> UserRead:
    user = service.update(user_id, payload)
    return UserRead.model_validate(user)


@router.delete(
    "/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a user",
)
def delete_user(user_id: int, service: UserServiceDep) -> None:
    service.delete(user_id)


@router.get(
    "/{user_id}/greetings",
    response_model=list[GreetingRead],
    summary="List greetings owned by a user",
)
def list_user_greetings(
    user_id: int,
    greetings: GreetingServiceDep,
    limit: int = Query(100, ge=1, le=500),
) -> list[GreetingRead]:
    items = greetings.list_for_user(user_id, limit=limit)
    return [GreetingRead.model_validate(g) for g in items]
