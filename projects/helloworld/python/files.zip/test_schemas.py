"""Unit tests for Pydantic schemas."""

import pytest
from pydantic import ValidationError as PydanticValidationError

from app.schemas.greeting import GreetingCreate, HelloResponse
from app.schemas.user import UserCreate, UserUpdate


class TestGreetingCreate:
    def test_valid_payload(self):
        assert GreetingCreate(name="Alice").name == "Alice"

    def test_accepts_optional_user_id(self):
        schema = GreetingCreate(name="Alice", user_id=42)
        assert schema.user_id == 42

    def test_rejects_empty_name(self):
        with pytest.raises(PydanticValidationError):
            GreetingCreate(name="")

    def test_rejects_too_long_name(self):
        with pytest.raises(PydanticValidationError):
            GreetingCreate(name="x" * 101)


class TestHelloResponse:
    def test_serialises_to_dict(self):
        assert HelloResponse(message="Hello, World!").model_dump() == {"message": "Hello, World!"}


class TestUserCreate:
    def test_valid_payload(self):
        user = UserCreate(email="alice@example.com", full_name="Alice")
        assert user.email == "alice@example.com"

    def test_rejects_invalid_email(self):
        with pytest.raises(PydanticValidationError):
            UserCreate(email="not-an-email", full_name="Alice")

    def test_rejects_empty_full_name(self):
        with pytest.raises(PydanticValidationError):
            UserCreate(email="alice@example.com", full_name="")


class TestUserUpdate:
    def test_all_fields_optional(self):
        # Empty is valid for PATCH
        assert UserUpdate().model_dump(exclude_unset=True) == {}

    def test_partial_update(self):
        upd = UserUpdate(full_name="New Name")
        assert upd.model_dump(exclude_unset=True) == {"full_name": "New Name"}
