"""Global exception handlers.

Translates domain exceptions into HTTP responses so service code can
raise meaningful errors without knowing about HTTP status codes.
"""

import logging

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

from app.exceptions import AppError, ConflictError, NotFoundError, ValidationError

logger = logging.getLogger(__name__)


def _error_response(status_code: int, message: str, error_type: str) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={"error": {"type": error_type, "message": message}},
    )


def register_exception_handlers(app: FastAPI) -> None:
    """Attach handlers for all our domain exceptions to the FastAPI app."""

    @app.exception_handler(NotFoundError)
    async def _not_found(_: Request, exc: NotFoundError) -> JSONResponse:
        return _error_response(status.HTTP_404_NOT_FOUND, exc.message, "not_found")

    @app.exception_handler(ConflictError)
    async def _conflict(_: Request, exc: ConflictError) -> JSONResponse:
        return _error_response(status.HTTP_409_CONFLICT, exc.message, "conflict")

    @app.exception_handler(ValidationError)
    async def _validation(_: Request, exc: ValidationError) -> JSONResponse:
        return _error_response(
            status.HTTP_422_UNPROCESSABLE_ENTITY, exc.message, "validation_error"
        )

    @app.exception_handler(AppError)
    async def _app_error(_: Request, exc: AppError) -> JSONResponse:
        logger.error("unhandled AppError: %s", exc.message)
        return _error_response(status.HTTP_500_INTERNAL_SERVER_ERROR, exc.message, "app_error")
