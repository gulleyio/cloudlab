"""FastAPI application entry point."""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app import models  # noqa: F401  -- registers models with Base.metadata
from app.api import api_router
from app.core.config import settings
from app.core.logging import configure_logging
from app.db.session import Base, get_engine
from app.middleware.exception_handlers import register_exception_handlers
from app.middleware.request_id import RequestIdMiddleware

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(_: FastAPI):
    """Startup / shutdown hooks.

    In production, run Alembic migrations instead of create_all. We only
    auto-create when ENVIRONMENT == 'development' so the test/prod paths
    never accidentally diverge from migrations.
    """
    if settings.ENVIRONMENT == "development":
        logger.info("creating tables (development mode)")
        Base.metadata.create_all(bind=get_engine())
    logger.info("application startup complete")
    yield
    logger.info("application shutdown")


def create_app() -> FastAPI:
    """Application factory.

    Using a factory keeps the app constructable for tests with overrides
    and avoids module-import side effects.
    """
    configure_logging(
        level="DEBUG" if settings.DEBUG else "INFO",
        json_logs=settings.ENVIRONMENT == "production",
    )

    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        debug=settings.DEBUG,
        lifespan=lifespan,
    )

    # Order matters: middleware wraps inside-out, so RequestIdMiddleware
    # is added first to ensure the request_id is set for everything else.
    app.add_middleware(RequestIdMiddleware)

    register_exception_handlers(app)
    app.include_router(api_router, prefix=settings.API_V1_PREFIX)
    return app


app = create_app()
